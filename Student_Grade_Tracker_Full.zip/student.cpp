#include "student.h"
#include <iostream>
using namespace std;

Student::Student(string n, int i, float g) : name(n), id(i), grade(g) {}

void Student::display() {
    cout << "Name: " << name << ", ID: " << id << ", Grade: " << grade << endl;
}

Student::~Student() {}
