#ifndef GRAD_STUDENT_H
#define GRAD_STUDENT_H

#include "student.h"

class GradStudent : public Student {
private:
    string thesisTitle;

public:
    GradStudent(string n = "", int i = 0, float g = 0.0, string t = "");
    void display() override;
};

#endif
