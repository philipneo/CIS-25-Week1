#include "fileio.h"
#include <fstream>
#include <iostream>
using namespace std;

void saveToFile(const vector<Student*>& students, const string& filename) {
    ofstream out(filename);
    for (const auto& s : students) {
        // Extend this to save actual student data
        out << "Student Data Placeholder" << endl;
    }
    out.close();
}

void loadFromFile(vector<Student*>& students, const string& filename) {
    ifstream in(filename);
    string line;
    while (getline(in, line)) {
        // Extend this to load student data from file
        cout << "Loading: " << line << endl;
    }
    in.close();
}
