#include "grad_student.h"
#include <iostream>
using namespace std;

GradStudent::GradStudent(string n, int i, float g, string t) : Student(n, i, g), thesisTitle(t) {}

void GradStudent::display() {
    Student::display();
    cout << "Thesis Title: " << thesisTitle << endl;
}
