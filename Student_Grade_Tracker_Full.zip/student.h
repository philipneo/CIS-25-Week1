#ifndef STUDENT_H
#define STUDENT_H

#include <string>
using namespace std;

class Student {
protected:
    string name;
    int id;
    float grade;

public:
    Student(string n = "", int i = 0, float g = 0.0);
    virtual void display();
    virtual ~Student();
};

#endif
