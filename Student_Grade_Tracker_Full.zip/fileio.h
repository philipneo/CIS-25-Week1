#ifndef FILEIO_H
#define FILEIO_H

#include <vector>
#include <string>
#include "student.h"

void saveToFile(const vector<Student*>& students, const string& filename);
void loadFromFile(vector<Student*>& students, const string& filename);

#endif
