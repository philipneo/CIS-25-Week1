#include <iostream>
#include "student.h"
#include "fileio.h"
using namespace std;

int main() {
    cout << "Welcome to Student Grade Tracker!" << endl;

    // Future logic: menu, add/edit student, file I/O, etc.
    return 0;
}
