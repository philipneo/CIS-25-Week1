#include "InventoryManager.h"

int main() {
    InventoryManager mgr;
    mgr.accessLevel();  // Should print: Full Inventory Management Access
    return 0;
}
