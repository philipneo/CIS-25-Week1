#pragma once
#include "User.h"

class Employee : public User {
public:
    void accessLevel() override {
        cout << "Employee Access\n";
    }
};
