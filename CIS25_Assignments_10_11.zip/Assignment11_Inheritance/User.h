#pragma once
#include <iostream>
using namespace std;

class User {
public:
    virtual void accessLevel() {
        cout << "General Access\n";
    }
};
